export const dynamic = 'force-dynamic';

export default function PricingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
