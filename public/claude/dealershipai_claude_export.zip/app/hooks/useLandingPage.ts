export function useLandingPage() {
  return {
    url: '',
    handleUrlChange: () => {},
    analyzeWebsite: () => {},
    isLoading: false,
    error: null,
    results: null
  };
}
