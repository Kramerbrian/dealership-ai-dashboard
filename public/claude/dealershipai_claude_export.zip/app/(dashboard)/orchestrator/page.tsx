'use client';

import OrchestratorCommandCenter from './OrchestratorCommandCenter';

export default function OrchestratorPage() {
  return <OrchestratorCommandCenter />;
}
