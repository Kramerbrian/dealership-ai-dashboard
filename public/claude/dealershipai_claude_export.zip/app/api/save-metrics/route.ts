import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { clerkClient } from '@clerk/nextjs/server'

export const runtime = 'nodejs'

/**
 * POST /api/save-metrics
 * Saves PVR (Parts, Vehicle, Repair) and Ad Expense PVR metrics
 */
export async function POST(req: NextRequest) {
  try {
    const user = await currentUser()

    if (!user) {
      return NextResponse.json(
        { ok: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    const body = await req.json().catch(() => ({}))
    const { pvr, adExpensePvr } = body

    // Validate inputs
    if (pvr === undefined || adExpensePvr === undefined) {
      return NextResponse.json(
        { ok: false, error: 'PVR and Ad Expense PVR are required' },
        { status: 400 }
      )
    }

    // Get existing metadata
    const existingMetadata = (user.publicMetadata || {}) as Record<string, any>

    // Prepare updated metadata
    const updatedMetadata: Record<string, any> = {
      ...existingMetadata,
      pvr: Number(pvr),
      adExpensePvr: Number(adExpensePvr),
      metricsSavedAt: new Date().toISOString(),
    }

    // Update Clerk metadata
    try {
      await clerkClient.users.updateUserMetadata(user.id, {
        publicMetadata: updatedMetadata,
      })
    } catch (error: any) {
      console.error('Failed to update Clerk metadata:', error)
      return NextResponse.json(
        { ok: false, error: 'Failed to save metrics' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      ok: true,
      message: 'Metrics saved successfully',
      metadata: updatedMetadata,
    })
  } catch (error: any) {
    console.error('Save metrics API error:', error)
    return NextResponse.json(
      { ok: false, error: error.message || 'Failed to save metrics' },
      { status: 500 }
    )
  }
}

