import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import fs from 'fs/promises';
import path from 'path';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

/**
 * GET /api/claude/export
 * Returns metadata about the latest Claude export package
 */
export async function GET(request: NextRequest) {
  try {
    // Get latest export metadata from Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { data: latestExport, error } = await supabase
      .from('claude_exports')
      .select('*')
      .order('exported_at', { ascending: false })
      .limit(1)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching export metadata:', error);
    }

    // Get file stats from public directory
    const exportPath = path.join(process.cwd(), 'public/claude/dealershipai_claude_export.zip');
    let fileSizeBytes = 0;
    let fileExists = false;

    try {
      const stats = await fs.stat(exportPath);
      fileSizeBytes = stats.size;
      fileExists = true;
    } catch (err) {
      console.warn('Export file not found:', exportPath);
    }

    // Load manifest
    const manifestPath = path.join(process.cwd(), 'exports/manifest.json');
    let manifest = null;

    try {
      const manifestContent = await fs.readFile(manifestPath, 'utf-8');
      manifest = JSON.parse(manifestContent);
    } catch (err) {
      console.warn('Manifest not found:', manifestPath);
    }

    // Construct response
    const baseUrl = request.nextUrl.origin;
    const downloadUrl = fileExists ? `${baseUrl}/claude/dealershipai_claude_export.zip` : null;

    return NextResponse.json({
      success: true,
      export: {
        version: manifest?.version || latestExport?.version || '3.0.0',
        downloadUrl,
        manifestUrl: `${baseUrl}/api/claude/manifest`,
        fileSize: fileSizeBytes,
        fileSizeMB: (fileSizeBytes / (1024 * 1024)).toFixed(2),
        lastExported: latestExport?.exported_at || new Date().toISOString(),
        downloadCount: latestExport?.download_count || 0,
        manifest: manifest ? {
          projectName: manifest.project_name,
          description: manifest.description,
          framework: manifest.framework,
          lastUpdated: manifest.last_updated,
        } : null,
      },
      instructions: {
        claudePrompt: `Load project from ${downloadUrl}\n\nManifest: /exports/manifest.json\n\nBuild cinematic Next.js 14 interface with Clerk + Framer Motion. Use the cognitive interface patterns and maintain brand hue continuity.`,
        quickStart: [
          'Download the ZIP archive',
          'Extract to your local machine',
          'Run: npm install',
          'Copy .env.example to .env.local and configure',
          'Run: npm run dev',
        ],
      },
    });
  } catch (error) {
    console.error('Export metadata error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch export metadata',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/claude/export
 * Log a new export generation
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      version,
      fileSizeBytes,
      filePath,
      manifestVersion,
      gitBranch,
      gitCommit,
      exportedBy,
      metadata = {},
    } = body;

    if (!version || !fileSizeBytes || !filePath) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { data, error } = await supabase
      .from('claude_exports')
      .insert({
        version,
        file_size_bytes: fileSizeBytes,
        file_path: filePath,
        manifest_version: manifestVersion,
        git_branch: gitBranch,
        git_commit: gitCommit,
        exported_by: exportedBy,
        metadata,
      })
      .select()
      .single();

    if (error) {
      console.error('Error logging export:', error);
      return NextResponse.json(
        { success: false, error: 'Failed to log export' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      export: data,
    });
  } catch (error) {
    console.error('Export logging error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to log export',
      },
      { status: 500 }
    );
  }
}
