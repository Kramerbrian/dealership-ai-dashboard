/**
 * Public API for DealershipAI
 * Provides access to AI visibility insights and competitive intelligence
 */

import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export interface PublicInsight {
  id: string;
  domain: string;
  aiVisibility: number;
  rank: number;
  total: number;
  quickWins: number;
  lastUpdated: string;
  trends: {
    score: number;
    rank: number;
    quickWins: number;
  }[];
  competitors: {
    name: string;
    domain: string;
    aiVisibility: number;
    gap: number;
  }[];
}

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  rateLimit?: {
    remaining: number;
    reset: number;
  };
}

// Mock API key validation
function validateApiKey(apiKey: string): boolean {
  // In production, this would validate against database
  return apiKey === 'demo-api-key' || apiKey.startsWith('dai_');
}

// Rate limiting (mock)
const rateLimitMap = new Map<string, { count: number; reset: number }>();

function checkRateLimit(apiKey: string): { allowed: boolean; remaining: number; reset: number } {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute window
  const maxRequests = 100; // 100 requests per minute
  
  const key = `rate_limit_${apiKey}`;
  const current = rateLimitMap.get(key) || { count: 0, reset: now + windowMs };
  
  if (now > current.reset) {
    current.count = 0;
    current.reset = now + windowMs;
  }
  
  if (current.count >= maxRequests) {
    return { allowed: false, remaining: 0, reset: current.reset };
  }
  
  current.count++;
  rateLimitMap.set(key, current);
  
  return { allowed: true, remaining: maxRequests - current.count, reset: current.reset };
}

export async function GET(req: NextRequest) {
  try {
    const apiKey = req.headers.get('x-api-key');
    if (!apiKey || !validateApiKey(apiKey)) {
      return NextResponse.json(
        { success: false, error: 'Invalid or missing API key' },
        { status: 401 }
      );
    }

    const rateLimit = checkRateLimit(apiKey);
    if (!rateLimit.allowed) {
      return NextResponse.json(
        { success: false, error: 'Rate limit exceeded' },
        { status: 429, headers: { 'Retry-After': '60' } }
      );
    }

    const { searchParams } = new URL(req.url);
    const domain = searchParams.get('domain');
    
    if (!domain) {
      return NextResponse.json(
        { success: false, error: 'Domain parameter is required' },
        { status: 400 }
      );
    }

    // Mock insight data
    const insight: PublicInsight = {
      id: `insight_${Date.now()}`,
      domain,
      aiVisibility: 87.3,
      rank: 2,
      total: 12,
      quickWins: 5,
      lastUpdated: new Date().toISOString(),
      trends: [
        { score: 85.1, rank: 3, quickWins: 3 },
        { score: 86.7, rank: 2, quickWins: 4 },
        { score: 87.3, rank: 2, quickWins: 5 }
      ],
      competitors: [
        {
          name: 'Competitor A',
          domain: 'competitor-a.com',
          aiVisibility: 92.1,
          gap: 4.8
        },
        {
          name: 'Competitor B',
          domain: 'competitor-b.com',
          aiVisibility: 78.9,
          gap: -8.4
        }
      ]
    };

    const response: APIResponse<PublicInsight> = {
      success: true,
      data: insight,
      rateLimit: {
        remaining: rateLimit.remaining,
        reset: rateLimit.reset
      }
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST() {
  try {
    const apiKey = req.headers.get('x-api-key');
    if (!apiKey || !validateApiKey(apiKey)) {
      return NextResponse.json(
        { success: false, error: 'Invalid or missing API key' },
        { status: 401 }
      );
    }

    const rateLimit = checkRateLimit(apiKey);
    if (!rateLimit.allowed) {
      return NextResponse.json(
        { success: false, error: 'Rate limit exceeded' },
        { status: 429 }
      );
    }

    const body = await req.json();
    const { domain, scanType = 'full' } = body;

    if (!domain) {
      return NextResponse.json(
        { success: false, error: 'Domain is required' },
        { status: 400 }
      );
    }

    // Mock scan initiation
    const scanId = `scan_${Date.now()}`;
    
    const response: APIResponse<{ scanId: string; status: string; estimatedTime: number }> = {
      success: true,
      data: {
        scanId,
        status: 'queued',
        estimatedTime: 30
      },
      rateLimit: {
        remaining: rateLimit.remaining,
        reset: rateLimit.reset
      }
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
