export const dynamic = 'force-dynamic';

export default function DashLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
