DealershipAI 3.0 Cognitive Interface  
Next.js 14 + Clerk + Framer Motion + Tailwind + Zustand.

Claude Instructions:

1. Read exports/manifest.json  
2. Build or refine pages/components as requested.  
3. Never modify manifest key names.  
4. Keep output as valid TSX or JSON_PATCH diffs.
