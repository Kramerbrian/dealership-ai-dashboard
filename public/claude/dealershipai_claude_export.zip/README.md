# DealershipAI 3.0 Cognitive Interface

**Next.js 14** + **Clerk** + **Framer Motion** + **Tailwind** + **Zustand**

AI-powered dealership visibility and intelligence dashboard with:
- Multi-platform review aggregation
- Sentiment analysis
- Revenue impact calculations
- Real-time market pulse monitoring
- Cinematic UI/UX with brand-tinted motion continuity

## Claude Instructions

1. **Read** exports/manifest.json to understand the system architecture
2. **Build or refine** pages/components as requested
3. **Never modify** manifest key names
4. **Keep output** as valid TSX or JSON_PATCH diffs
5. **Follow** the cognitive interface patterns in components/cognitive/*
6. **Maintain** brand hue continuity using useBrandHue hook

## Quick Start (After Claude Generation)

\`\`\`bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env.local
# Edit .env.local with your API keys

# Run development server
npm run dev
\`\`\`

## Key Routes

- / → Cinematic landing page
- /onboarding → Live calibration flow
- /dashboard → Main dashboard
- /preview → Preview dashboard
- /drive → AI visibility testing
- /admin → Admin panel

## Architecture Highlights

- **Route Groups**: Uses Next.js App Router with route groups (marketing), (dashboard), (admin), (mkt)
- **Middleware**: Clerk authentication with custom route protection
- **Real-time Updates**: Supabase subscriptions + Upstash Redis caching
- **Cinematic UX**: Framer Motion animations with brand color theming
- **Type Safety**: Full TypeScript coverage with strict mode

## Database

Supabase PostgreSQL with migrations in /supabase/migrations/

Key tables:
- telemetry_events - System event tracking
- dealers - Dealer profiles
- integrations - Third-party API connections

## Deployment

Optimized for Vercel deployment with:
- Edge middleware
- API route rate limiting
- Automatic preview deployments
- Environment variable management

---

**Generated**: $(date +"%Y-%m-%d %H:%M:%S")
**Export Version**: 3.0-cognitive
