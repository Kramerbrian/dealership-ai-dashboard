DealershipAI Cognitive Interface v3.1
Next.js 14 • Clerk • Framer Motion • Tailwind • Zustand

Claude Instructions:
1. Read exports/manifest.json first.
2. Maintain TSX and JSON structures.
3. Output diffs or new files only.
4. Never rename manifest keys.

Author: Brian Kramer
