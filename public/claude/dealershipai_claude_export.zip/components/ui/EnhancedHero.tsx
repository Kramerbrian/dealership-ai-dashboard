export function EnhancedHero({ onAnalyze }: any) {
  return null;
}
