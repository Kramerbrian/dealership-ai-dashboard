export function EnhancedFeedbackWidget() {
  return null;
}

