export function UrlEntryModal({ isOpen, onClose, onSubmit }: any) {
  return null;
}
