
import { PulseOverview } from '@/components/dashboard/PulseOverview';

async function fetchClarity(domain?: string) {
  const qs = new URLSearchParams();
  if (domain) qs.set('domain', domain);
  const base = process.env.NEXT_PUBLIC_BASE_URL || '';
  const url = base
    ? `${base}/api/clarity/stack?${qs.toString()}`
    : `/api/clarity/stack?${qs.toString()}`;

  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) {
    throw new Error('Failed to load clarity stack');
  }
  return res.json();
}

export default async function DashPage({ searchParams }: { searchParams?: { domain?: string } }) {
  const domain = searchParams?.domain || 'exampledealer.com';
  const data = await fetchClarity(domain);

  return (
    <main className="min-h-dvh bg-neutral-950 text-white px-6 py-8">
      <PulseOverview
        domain={data.domain}
        scores={data.scores}
        gbp={data.gbp}
        ugc={{
          score: data.ugc.score,
          recent_reviews_90d: data.ugc.recent_reviews_90d
        }}
        schema={{ score: data.schema.score }}
        competitive={{
          rank: data.competitive.rank,
          total: data.competitive.total
        }}
        revenueMonthly={data.revenue_at_risk.monthly}
      />
    </main>
  );
}
