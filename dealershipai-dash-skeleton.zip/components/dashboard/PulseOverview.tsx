
'use client';

type Scores = { seo: number; aeo: number; geo: number; avi: number };
type Gbp = { health_score: number; rating?: number; review_count?: number };
type Ugc = { score: number; recent_reviews_90d: number };
type Schema = { score: number };
type Competitive = { rank: number; total: number };

type Props = {
  domain: string;
  scores: Scores;
  gbp: Gbp;
  ugc: Ugc;
  schema: Schema;
  competitive: Competitive;
  revenueMonthly: number;
};

function statusColor(score: number) {
  if (score >= 80) return 'text-emerald-400';
  if (score >= 60) return 'text-amber-400';
  return 'text-red-400';
}

function pillBg(score: number) {
  if (score >= 80) return 'bg-emerald-500/15 border-emerald-500/40';
  if (score >= 60) return 'bg-amber-500/15 border-amber-500/40';
  return 'bg-red-500/15 border-red-500/40';
}

export function PulseOverview({
  domain,
  scores,
  gbp,
  ugc,
  schema,
  competitive,
  revenueMonthly
}: Props) {
  return (
    <div className="space-y-8">
      <section className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold">
            Pulse overview
          </h1>
          <p className="mt-2 text-sm text-white/60">
            This is how AI sees <span className="font-mono text-white/80">{domain}</span> right now.
          </p>
        </div>
        <div className="text-right">
          <div className="text-xs text-white/50 uppercase tracking-[0.16em]">
            Revenue at risk
          </div>
          <div className="text-lg font-semibold">
            ${revenueMonthly.toLocaleString()}/month
          </div>
          <div className="text-[11px] text-white/40">
            From AI visibility gaps.
          </div>
        </div>
      </section>

      <section>
        <div className="text-xs text-white/50 uppercase tracking-[0.16em] mb-2">
          Clarity stack
        </div>
        <div className="grid gap-3 md:grid-cols-4">
          {[
            { key: 'SEO', value: scores.seo, desc: 'How easy your site is to read.' },
            { key: 'AEO', value: scores.aeo, desc: 'How well you answer shopper questions.' },
            { key: 'GEO', value: scores.geo, desc: 'How visible you are in AI answers.' },
            { key: 'AVI', value: scores.avi, desc: 'Your overall AI visibility score.' }
          ].map((tile) => (
            <div
              key={tile.key}
              className={`rounded-2xl border px-4 py-3 ${pillBg(tile.value)}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/60">{tile.key}</span>
                <span className={`text-sm font-semibold ${statusColor(tile.value)}`}>
                  {tile.value}/100
                </span>
              </div>
              <div className="mt-1 text-[11px] text-white/50">
                {tile.desc}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="text-xs text-white/50 uppercase tracking-[0.16em] mb-2">
          System & local signals
        </div>
        <div className="grid gap-3 md:grid-cols-4">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-white/60">GBP health</span>
              <span className={`text-sm font-semibold ${statusColor(gbp.health_score)}`}>
                {gbp.health_score}/100
              </span>
            </div>
            <div className="mt-1 text-[11px] text-white/50">
              Rating {gbp.rating?.toFixed(1) ?? '–'} with {gbp.review_count ?? 0} reviews.
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-white/60">UGC & reviews</span>
              <span className={`text-sm font-semibold ${statusColor(ugc.score)}`}>
                {ugc.score}/100
              </span>
            </div>
            <div className="mt-1 text-[11px] text-white/50">
              {ugc.recent_reviews_90d} reviews in the last 90 days.
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-white/60">Schema coverage</span>
              <span className={`text-sm font-semibold ${statusColor(schema.score)}`}>
                {schema.score}/100
              </span>
            </div>
            <div className="mt-1 text-[11px] text-white/50">
              How clearly your pages are marked up for AI.
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-white/60">Competitive position</span>
              <span className="text-sm font-semibold text-white/80">
                #{competitive.rank} of {competitive.total}
              </span>
            </div>
            <div className="mt-1 text-[11px] text-white/50">
              Your spot in the local AI field.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
